<?php
session_start();
if(!isset($_SESSION['examsection'])) {
    echo "You don't have permission";
    exit();
}
include 'include_db_details.php';
$exam_name = $_POST['exam_id'];
$regulation = $_POST['regulation'];
$semester = $_POST['semester'];
$amount = $_POST['amount'];

$query = $con->prepare("INSERT INTO `regular_exams` (`name`,`regulation`,`semester`,`amount`) VALUES ('$exam_name','$regulation','$semester','$amount')");

function redirect($url, $statusCode = 303)
{
    header('Location: ' . $url, true, $statusCode);
    die();
}

if ($query->execute()) {
    redirect("examsection_home.php?infomsg=Exam Added Successfully");
} else {
    redirect("examsection_home.php?errormsg=Error adding exam");
}

?>
